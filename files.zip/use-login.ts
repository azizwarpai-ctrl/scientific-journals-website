import { useMutation, useQueryClient } from "@tanstack/react-query"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { client } from "@/src/lib/rpc"
import type { LoginInput } from "../schemas/auth-schema"

interface LoginResult {
  id: string
  email: string
  role: string
}

export const useLogin = () => {
  const router = useRouter()
  const queryClient = useQueryClient()

  return useMutation<LoginResult, Error, LoginInput>({
    mutationFn: async (values) => {
      const response = await client.api.auth.login.$post({ json: values })

      if (!response.ok) {
        const body = (await response.json()) as any
        throw new Error(body.error ?? "Login failed")
      }

      const { user } = await response.json()
      return user as LoginResult
    },
    onSuccess: () => {
      toast.success("Logged in successfully")
      queryClient.invalidateQueries({ queryKey: ["current-user"] })
      router.push("/admin/dashboard")
      router.refresh()
    },
    onError: (error) => {
      toast.error(error.message || "Login failed")
    },
  })
}
