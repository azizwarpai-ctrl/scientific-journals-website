import { useMutation, useQueryClient } from "@tanstack/react-query"
import { toast } from "sonner"
import { client } from "@/src/lib/rpc"
import type { SolutionCreate } from "../schemas/solution-schema"
import type { Solution } from "../types/solution-type"

export const useCreateSolution = () => {
  const queryClient = useQueryClient()

  return useMutation<Solution, Error, SolutionCreate>({
    mutationFn: async (values) => {
      const response = await client.api.solutions.$post({ json: values })

      if (!response.ok) {
        const body = (await response.json()) as any
        throw new Error(body.error ?? "Failed to create FAQ")
      }

      const { data } = await response.json()
      return data as Solution
    },
    onSuccess: () => {
      toast.success("FAQ created successfully")
      queryClient.invalidateQueries({ queryKey: ["solutions"] })
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create FAQ")
    },
  })
}
