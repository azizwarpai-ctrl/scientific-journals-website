import { useQuery } from "@tanstack/react-query"
import { client } from "@/src/lib/rpc"
import type { Message } from "../types/message-type"

export const useGetMessage = (id: string) => {
  return useQuery<Message, Error>({
    queryKey: ["messages", id],
    queryFn: async () => {
      const response = await client.api.messages[":id"].$get({
        param: { id },
      })

      if (!response.ok) {
        const body = (await response.json()) as any
        throw new Error(body.error ?? "Failed to fetch message")
      }

      const { data } = await response.json()
      return data as Message
    },
    enabled: !!id,
  })
}
