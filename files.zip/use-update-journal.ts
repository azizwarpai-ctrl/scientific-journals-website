import { useMutation, useQueryClient } from "@tanstack/react-query"
import { toast } from "sonner"
import { client } from "@/src/lib/rpc"
import type { JournalUpdate } from "../schemas/journal-schema"
import type { Journal } from "../types/journal-type"

interface UpdateJournalVariables {
  id: string
  data: JournalUpdate
}

export const useUpdateJournal = () => {
  const queryClient = useQueryClient()

  return useMutation<Journal, Error, UpdateJournalVariables>({
    mutationFn: async ({ id, data }) => {
      const response = await client.api.journals[":id"].$patch({
        param: { id },
        json: data,
      })

      if (!response.ok) {
        const body = (await response.json()) as any
        throw new Error(body.error ?? "Failed to update journal")
      }

      const { data: journal } = await response.json()
      return journal as Journal
    },
    onSuccess: (_, { id }) => {
      toast.success("Journal updated successfully")
      queryClient.invalidateQueries({ queryKey: ["journals"] })
      queryClient.invalidateQueries({ queryKey: ["journals", id] })
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update journal")
    },
  })
}
