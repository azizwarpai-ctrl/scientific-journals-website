import { useMutation, useQueryClient } from "@tanstack/react-query"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { client } from "@/src/lib/rpc"

export const useLogout = () => {
  const router = useRouter()
  const queryClient = useQueryClient()

  return useMutation<void, Error, void>({
    mutationFn: async () => {
      const response = await client.api.auth.logout.$post()

      if (!response.ok) {
        const body = (await response.json()) as any
        throw new Error(body.error ?? "Logout failed")
      }
    },
    onSuccess: () => {
      toast.success("Logged out successfully")
      queryClient.setQueryData(["current-user"], null)
      queryClient.clear()
      router.push("/admin/login")
      router.refresh()
    },
    onError: (error) => {
      toast.error(error.message || "Logout failed")
    },
  })
}
