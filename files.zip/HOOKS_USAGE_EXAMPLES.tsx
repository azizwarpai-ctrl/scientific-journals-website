"use client"

/**
 * EXAMPLE: admin/login/page.tsx refactored to use the useLogin hook.
 *
 * Before (manual fetch):
 *   const response = await fetch("/api/auth/login", { method: "POST", ... })
 *   router.push("/admin/dashboard")
 *
 * After (hook):
 *   const { mutate: login, isPending } = useLogin()
 *   login({ email, password })
 *   // toast + redirect + cache invalidation are handled automatically
 */

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import Image from "next/image"
import { useLogin } from "@/src/features/auth"

export default function AdminLoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")

  // ✅ replaces manual fetch + router.push + error setState
  const { mutate: login, isPending, error } = useLogin()

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    login({ email, password })
  }

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-gradient-to-br from-blue-50 via-white to-orange-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 p-6">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <Image
            src="/images/logodigitopub.png"
            alt="DigitoPub Logo"
            width={180}
            height={60}
            className="mx-auto mb-4"
          />
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Admin Portal</h1>
          <p className="text-sm text-muted-foreground mt-2">Sign in to manage your scientific journals</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Admin Login</CardTitle>
            <CardDescription>Enter your admin credentials to access the dashboard</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin}>
              <div className="flex flex-col gap-6">
                <div className="grid gap-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="admin@digitopub.com"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>

                {error && (
                  <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-3">
                    <p className="text-sm text-red-600 dark:text-red-400">{error.message}</p>
                  </div>
                )}

                <Button type="submit" className="w-full" disabled={isPending}>
                  {isPending ? "Signing in…" : "Sign In"}
                </Button>
              </div>
              <div className="mt-4 text-center text-sm text-muted-foreground">
                <Link href="/" className="underline underline-offset-4 hover:text-primary">
                  Back to main site
                </Link>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────────────────
 * EXAMPLE: admin/faq/new/page.tsx — using useCreateSolution
 *
 *   const { mutate: createFaq, isPending } = useCreateSolution()
 *
 *   const handleSubmit = (e) => {
 *     e.preventDefault()
 *     createFaq(
 *       { question, answer, category, is_published },
 *       { onSuccess: () => router.push("/admin/faq") }   // per-call override
 *     )
 *   }
 *
 * EXAMPLE: admin/journals — delete button
 *
 *   const { mutate: deleteJournal, isPending } = useDeleteJournal()
 *
 *   <Button
 *     variant="destructive"
 *     disabled={isPending}
 *     onClick={() => deleteJournal(journal.id)}
 *   >
 *     Delete
 *   </Button>
 *
 * EXAMPLE: contact/page.tsx — using useCreateMessage
 *
 *   const { mutate: sendMessage, isPending, isSuccess } = useCreateMessage()
 *
 *   const handleSubmit = (e) => {
 *     e.preventDefault()
 *     sendMessage({ name, email, subject, message, message_type: "contact" })
 *   }
 *
 * ───────────────────────────────────────────────────────────────────────────── */
