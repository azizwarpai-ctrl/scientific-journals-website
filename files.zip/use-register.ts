import { useMutation, useQueryClient } from "@tanstack/react-query"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { client } from "@/src/lib/rpc"
import type { RegisterInput } from "../schemas/auth-schema"

interface RegisterResult {
  id: string
  email: string
  role: string
}

export const useRegister = () => {
  const router = useRouter()
  const queryClient = useQueryClient()

  return useMutation<RegisterResult, Error, RegisterInput>({
    mutationFn: async (values) => {
      const response = await client.api.auth.register.$post({ json: values })

      if (!response.ok) {
        const body = (await response.json()) as any
        throw new Error(body.error ?? "Registration failed")
      }

      const { user } = await response.json()
      return user as RegisterResult
    },
    onSuccess: () => {
      toast.success("Account created successfully")
      queryClient.invalidateQueries({ queryKey: ["current-user"] })
      router.push("/admin/dashboard")
      router.refresh()
    },
    onError: (error) => {
      toast.error(error.message || "Registration failed")
    },
  })
}
