import { useQuery } from "@tanstack/react-query"
import { client } from "@/src/lib/rpc"
import type { Solution } from "../types/solution-type"

export const useGetSolution = (id: string) => {
  return useQuery<Solution, Error>({
    queryKey: ["solutions", id],
    queryFn: async () => {
      const response = await client.api.solutions[":id"].$get({
        param: { id },
      })

      if (!response.ok) {
        const body = (await response.json()) as any
        throw new Error(body.error ?? "Failed to fetch FAQ")
      }

      const { data } = await response.json()
      return data as Solution
    },
    enabled: !!id,
  })
}
