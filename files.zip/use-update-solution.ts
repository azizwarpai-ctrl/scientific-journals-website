import { useMutation, useQueryClient } from "@tanstack/react-query"
import { toast } from "sonner"
import { client } from "@/src/lib/rpc"
import type { SolutionUpdate } from "../schemas/solution-schema"
import type { Solution } from "../types/solution-type"

interface UpdateSolutionVariables {
  id: string
  data: SolutionUpdate
}

export const useUpdateSolution = () => {
  const queryClient = useQueryClient()

  return useMutation<Solution, Error, UpdateSolutionVariables>({
    mutationFn: async ({ id, data }) => {
      const response = await client.api.solutions[":id"].$patch({
        param: { id },
        json: data,
      })

      if (!response.ok) {
        const body = (await response.json()) as any
        throw new Error(body.error ?? "Failed to update FAQ")
      }

      const { data: solution } = await response.json()
      return solution as Solution
    },
    onSuccess: (_, { id }) => {
      toast.success("FAQ updated successfully")
      queryClient.invalidateQueries({ queryKey: ["solutions"] })
      queryClient.invalidateQueries({ queryKey: ["solutions", id] })
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update FAQ")
    },
  })
}
