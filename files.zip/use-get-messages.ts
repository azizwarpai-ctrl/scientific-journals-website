import { useQuery } from "@tanstack/react-query"
import { client } from "@/src/lib/rpc"
import type { Message } from "../types/message-type"

export const useGetMessages = () => {
  return useQuery<Message[], Error>({
    queryKey: ["messages"],
    queryFn: async () => {
      const response = await client.api.messages.$get()

      if (!response.ok) {
        const body = (await response.json()) as any
        throw new Error(body.error ?? "Failed to fetch messages")
      }

      const { data } = await response.json()
      return data as Message[]
    },
  })
}
