import { useMutation, useQueryClient } from "@tanstack/react-query"
import { toast } from "sonner"
import { client } from "@/src/lib/rpc"
import type { JournalCreate } from "../schemas/journal-schema"
import type { Journal } from "../types/journal-type"

export const useCreateJournal = () => {
  const queryClient = useQueryClient()

  return useMutation<Journal, Error, JournalCreate>({
    mutationFn: async (values) => {
      const response = await client.api.journals.$post({ json: values })

      if (!response.ok) {
        const body = (await response.json()) as any
        throw new Error(body.error ?? "Failed to create journal")
      }

      const { data } = await response.json()
      return data as Journal
    },
    onSuccess: () => {
      toast.success("Journal created successfully")
      queryClient.invalidateQueries({ queryKey: ["journals"] })
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create journal")
    },
  })
}
