import { useQuery } from "@tanstack/react-query"
import { client } from "@/src/lib/rpc"
import type { Journal } from "../types/journal-type"

export const useGetJournals = () => {
  return useQuery<Journal[], Error>({
    queryKey: ["journals"],
    queryFn: async () => {
      const response = await client.api.journals.$get()

      if (!response.ok) {
        const body = (await response.json()) as any
        throw new Error(body.error ?? "Failed to fetch journals")
      }

      const { data } = await response.json()
      return data as Journal[]
    },
  })
}
