import { useQuery } from "@tanstack/react-query"
import { client } from "@/src/lib/rpc"
import type { AuthUser } from "../types/auth-type"

export const useCurrentUser = () => {
  return useQuery<AuthUser | null, Error>({
    queryKey: ["current-user"],
    queryFn: async () => {
      const response = await client.api.auth.me.$get()

      // 401 simply means "not logged in" — not an error worth throwing
      if (response.status === 401) return null

      if (!response.ok) {
        const body = (await response.json()) as any
        throw new Error(body.error ?? "Failed to get current user")
      }

      const { user } = await response.json()
      return user as AuthUser
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: false,
  })
}
