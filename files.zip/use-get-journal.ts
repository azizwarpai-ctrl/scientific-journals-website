import { useQuery } from "@tanstack/react-query"
import { client } from "@/src/lib/rpc"
import type { Journal } from "../types/journal-type"

export const useGetJournal = (id: string) => {
  return useQuery<Journal, Error>({
    queryKey: ["journals", id],
    queryFn: async () => {
      const response = await client.api.journals[":id"].$get({
        param: { id },
      })

      if (!response.ok) {
        const body = (await response.json()) as any
        throw new Error(body.error ?? "Failed to fetch journal")
      }

      const { data } = await response.json()
      return data as Journal
    },
    enabled: !!id,
  })
}
