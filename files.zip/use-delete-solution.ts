import { useMutation, useQueryClient } from "@tanstack/react-query"
import { toast } from "sonner"
import { client } from "@/src/lib/rpc"

export const useDeleteSolution = () => {
  const queryClient = useQueryClient()

  return useMutation<void, Error, string>({
    mutationFn: async (id) => {
      const response = await client.api.solutions[":id"].$delete({
        param: { id },
      })

      if (!response.ok) {
        const body = (await response.json()) as any
        throw new Error(body.error ?? "Failed to delete FAQ")
      }
    },
    onSuccess: () => {
      toast.success("FAQ deleted successfully")
      queryClient.invalidateQueries({ queryKey: ["solutions"] })
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete FAQ")
    },
  })
}
