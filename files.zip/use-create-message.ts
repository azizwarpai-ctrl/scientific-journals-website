import { useMutation, useQueryClient } from "@tanstack/react-query"
import { toast } from "sonner"
import { client } from "@/src/lib/rpc"
import type { MessageCreate } from "../schemas/message-schema"
import type { Message } from "../types/message-type"

export const useCreateMessage = () => {
  const queryClient = useQueryClient()

  return useMutation<Message, Error, MessageCreate>({
    mutationFn: async (values) => {
      const response = await client.api.messages.$post({ json: values })

      if (!response.ok) {
        const body = (await response.json()) as any
        throw new Error(body.error ?? "Failed to send message")
      }

      const { data } = await response.json()
      return data as Message
    },
    onSuccess: () => {
      toast.success("Message sent successfully!")
      queryClient.invalidateQueries({ queryKey: ["messages"] })
    },
    onError: (error) => {
      toast.error(error.message || "Failed to send message")
    },
  })
}
