import { useMutation, useQueryClient } from "@tanstack/react-query"
import { toast } from "sonner"
import { client } from "@/src/lib/rpc"
import type { MessageUpdate } from "../schemas/message-schema"
import type { Message } from "../types/message-type"

interface UpdateMessageVariables {
  id: string
  data: MessageUpdate
}

export const useUpdateMessage = () => {
  const queryClient = useQueryClient()

  return useMutation<Message, Error, UpdateMessageVariables>({
    mutationFn: async ({ id, data }) => {
      const response = await client.api.messages[":id"].$patch({
        param: { id },
        json: data,
      })

      if (!response.ok) {
        const body = (await response.json()) as any
        throw new Error(body.error ?? "Failed to update message")
      }

      const { data: message } = await response.json()
      return message as Message
    },
    onSuccess: (_, { id }) => {
      toast.success("Message updated successfully")
      queryClient.invalidateQueries({ queryKey: ["messages"] })
      queryClient.invalidateQueries({ queryKey: ["messages", id] })
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update message")
    },
  })
}
