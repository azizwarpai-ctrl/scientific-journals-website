import { useQuery } from "@tanstack/react-query"
import { client } from "@/src/lib/rpc"
import type { Solution } from "../types/solution-type"

export const useGetSolutions = () => {
  return useQuery<Solution[], Error>({
    queryKey: ["solutions"],
    queryFn: async () => {
      const response = await client.api.solutions.$get()

      if (!response.ok) {
        const body = (await response.json()) as any
        throw new Error(body.error ?? "Failed to fetch FAQs")
      }

      const { data } = await response.json()
      return data as Solution[]
    },
  })
}
