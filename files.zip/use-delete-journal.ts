import { useMutation, useQueryClient } from "@tanstack/react-query"
import { toast } from "sonner"
import { client } from "@/src/lib/rpc"

export const useDeleteJournal = () => {
  const queryClient = useQueryClient()

  return useMutation<void, Error, string>({
    mutationFn: async (id) => {
      const response = await client.api.journals[":id"].$delete({
        param: { id },
      })

      if (!response.ok) {
        const body = (await response.json()) as any
        throw new Error(body.error ?? "Failed to delete journal")
      }
    },
    onSuccess: () => {
      toast.success("Journal deleted successfully")
      queryClient.invalidateQueries({ queryKey: ["journals"] })
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete journal")
    },
  })
}
