// Schemas & types
export { messageCreateSchema, messageUpdateSchema, messageIdParamSchema } from "./schemas/message-schema"
export type { MessageCreate, MessageUpdate } from "./schemas/message-schema"
export type { Message, MessageResponse } from "./types/message-type"

// Hono router
export { messageRouter } from "./server/route"

// React Query hooks
export { useGetMessages } from "./api/use-get-messages"
export { useGetMessage } from "./api/use-get-message"
export { useCreateMessage } from "./api/use-create-message"
export { useUpdateMessage } from "./api/use-update-message"
export { useDeleteMessage } from "./api/use-delete-message"
