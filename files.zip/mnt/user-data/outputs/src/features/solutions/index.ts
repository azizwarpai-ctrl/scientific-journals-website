// Schemas & types
export { solutionCreateSchema, solutionUpdateSchema, solutionIdParamSchema } from "./schemas/solution-schema"
export type { SolutionCreate, SolutionUpdate } from "./schemas/solution-schema"
export type { Solution, SolutionResponse } from "./types/solution-type"

// Hono router
export { solutionRouter } from "./server/route"

// React Query hooks
export { useGetSolutions } from "./api/use-get-solutions"
export { useGetSolution } from "./api/use-get-solution"
export { useCreateSolution } from "./api/use-create-solution"
export { useUpdateSolution } from "./api/use-update-solution"
export { useDeleteSolution } from "./api/use-delete-solution"
