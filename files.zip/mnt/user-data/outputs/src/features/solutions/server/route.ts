import { Hono } from "hono"
import { zValidator } from "@hono/zod-validator"
import { getSession } from "@/lib/db/auth"
import { prisma } from "@/lib/db/config"
import {
  solutionCreateSchema,
  solutionUpdateSchema,
  solutionIdParamSchema,
} from "../schemas/solution-schema"
import type { Solution } from "../types/solution-type"

const app = new Hono()

const serializeSolution = (solution: any): Solution => ({
  ...solution,
  id: solution.id.toString(),
})

// ─── GET /solutions ────────────────────────────────────────────────────────────
app.get("/", async (c) => {
  try {
    const session = await getSession()
    const where = session ? {} : { is_published: true }

    const solutions = await prisma.fAQ.findMany({
      where,
      select: {
        id: true,
        question: true,
        answer: true,
        category: true,
        is_published: true,
        view_count: true,
        helpful_count: true,
        created_at: true,
        updated_at: true,
      },
      orderBy: { created_at: "desc" },
    })

    return c.json({ success: true, data: solutions.map(serializeSolution) }, 200)
  } catch (error) {
    console.error("Error fetching solutions:", error)
    return c.json({ success: false, error: "Failed to fetch solutions" }, 500)
  }
})

// ─── GET /solutions/:id ────────────────────────────────────────────────────────
app.get(
  "/:id",
  zValidator("param", solutionIdParamSchema),
  async (c) => {
    try {
      const { id } = c.req.valid("param")

      const solution = await prisma.fAQ.findUnique({
        where: { id: BigInt(id) },
        select: {
          id: true,
          question: true,
          answer: true,
          category: true,
          is_published: true,
          view_count: true,
          helpful_count: true,
          created_at: true,
          updated_at: true,
        },
      })

      if (!solution) {
        return c.json({ success: false, error: "Solution not found" }, 404)
      }

      if (!solution.is_published) {
        const session = await getSession()
        if (!session) {
          return c.json({ success: false, error: "Not found" }, 404)
        }
      }

      return c.json({ success: true, data: serializeSolution(solution) }, 200)
    } catch (error) {
      console.error("Error fetching solution:", error)
      return c.json({ success: false, error: "Failed to fetch solution" }, 500)
    }
  }
)

// ─── POST /solutions ───────────────────────────────────────────────────────────
app.post(
  "/",
  zValidator("json", solutionCreateSchema),
  async (c) => {
    try {
      const session = await getSession()
      if (!session) {
        return c.json({ success: false, error: "Unauthorized" }, 401)
      }

      const data = c.req.valid("json")

      const solution = await prisma.fAQ.create({
        data: {
          question: data.question,
          answer: data.answer,
          category: data.category ?? "general",
          is_published: data.is_published ?? false,
        },
        select: {
          id: true,
          question: true,
          answer: true,
          category: true,
          is_published: true,
          view_count: true,
          helpful_count: true,
          created_at: true,
          updated_at: true,
        },
      })

      return c.json(
        {
          success: true,
          data: serializeSolution(solution),
          message: "FAQ created successfully",
        },
        201
      )
    } catch (error) {
      console.error("Error creating solution:", error)
      return c.json({ success: false, error: "Failed to create FAQ" }, 500)
    }
  }
)

// ─── PATCH /solutions/:id ──────────────────────────────────────────────────────
app.patch(
  "/:id",
  zValidator("param", solutionIdParamSchema),
  zValidator("json", solutionUpdateSchema),
  async (c) => {
    try {
      const session = await getSession()
      if (!session) {
        return c.json({ success: false, error: "Unauthorized" }, 401)
      }

      const { id } = c.req.valid("param")
      const data = c.req.valid("json")

      const existing = await prisma.fAQ.findUnique({
        where: { id: BigInt(id) },
        select: { id: true },
      })

      if (!existing) {
        return c.json({ success: false, error: "Solution not found" }, 404)
      }

      const updateData: Record<string, unknown> = {}
      if (data.question !== undefined) updateData.question = data.question
      if (data.answer !== undefined) updateData.answer = data.answer
      if (data.category !== undefined) updateData.category = data.category
      if (data.is_published !== undefined) updateData.is_published = data.is_published

      const solution = await prisma.fAQ.update({
        where: { id: BigInt(id) },
        data: updateData,
        select: {
          id: true,
          question: true,
          answer: true,
          category: true,
          is_published: true,
          view_count: true,
          helpful_count: true,
          created_at: true,
          updated_at: true,
        },
      })

      return c.json(
        {
          success: true,
          data: serializeSolution(solution),
          message: "FAQ updated successfully",
        },
        200
      )
    } catch (error) {
      console.error("Error updating solution:", error)
      return c.json({ success: false, error: "Failed to update FAQ" }, 500)
    }
  }
)

// ─── DELETE /solutions/:id ─────────────────────────────────────────────────────
app.delete(
  "/:id",
  zValidator("param", solutionIdParamSchema),
  async (c) => {
    try {
      const session = await getSession()
      if (!session) {
        return c.json({ success: false, error: "Unauthorized" }, 401)
      }

      const { id } = c.req.valid("param")

      const existing = await prisma.fAQ.findUnique({
        where: { id: BigInt(id) },
        select: { id: true },
      })

      if (!existing) {
        return c.json({ success: false, error: "Solution not found" }, 404)
      }

      await prisma.fAQ.delete({ where: { id: BigInt(id) } })

      return c.json({ success: true, message: "FAQ deleted successfully" }, 200)
    } catch (error) {
      console.error("Error deleting solution:", error)
      return c.json({ success: false, error: "Failed to delete FAQ" }, 500)
    }
  }
)

export { app as solutionRouter }
