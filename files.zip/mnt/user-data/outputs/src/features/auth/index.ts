// Schemas & types
export { loginSchema, registerSchema } from "./schemas/auth-schema"
export type { LoginInput, RegisterInput } from "./schemas/auth-schema"
export type { AuthUser, AuthResponse } from "./types/auth-type"

// Hono router
export { authRouter } from "./server/route"

// React Query hooks
export { useCurrentUser } from "./api/use-current-user"
export { useLogin } from "./api/use-login"
export { useRegister } from "./api/use-register"
export { useLogout } from "./api/use-logout"
